package Day2.Loop;

public class pattern {
	public static void main(String[] arg) {
		for(int i=1;i<=5;i++) {
			for(int j=1;j<=i;j++) {
				System.out.print(" * ");
				
			}
			System.out.println("");
		}
	}

}
